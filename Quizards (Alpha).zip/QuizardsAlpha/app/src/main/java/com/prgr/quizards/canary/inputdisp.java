package com.prgr.quizards.canary;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class inputdisp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inputdisp);
    }
}